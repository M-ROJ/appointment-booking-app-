# Appointment Booking App

## Features
- Book and view appointments using a simple web UI.
- Built with Node.js, Express, MongoDB, and Vanilla JS.

## Setup Instructions
1. Create a `.env` file with your MongoDB URI.
2. Run `npm install`.
3. Run `npm start`.
4. Open `frontend/index.html` in your browser.