document.getElementById('appointmentForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;

    await fetch('http://localhost:5000/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, date, time })
    });

    loadAppointments();
});

async function loadAppointments() {
    const res = await fetch('http://localhost:5000/api/appointments');
    const appointments = await res.json();
    const list = document.getElementById('appointmentsList');
    list.innerHTML = '';
    appointments.forEach(app => {
        const item = document.createElement('li');
        item.textContent = `${app.name} - ${app.date} at ${app.time}`;
        list.appendChild(item);
    });
}

loadAppointments();